package com.lti.Mapping.OneToMany;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;


public class App 
{
    public static void main( String[] args )
    {
    	EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("HEY");
        EntityManager entityManager=entityManagerFactory.createEntityManager();
        
        System.out.println("Starting Transaction");
       
        
      /*  Category category = new Category("CLOTHS");
        Product pc=new Product("DELL PC","QuadCore", 1200,category);
        
        Product laptop =new Product("MacBook","Apple laptop",2100,category);
        Product phone =new Product("MacBook","Apple laptop",2100,category);
        Product tablet =new Product("MacBook","Apple laptop",2100,category);
        
        Set<Product> prod=new HashSet<Product>();
        prod.add(pc);
        prod.add(laptop);
        prod.add(phone);
        prod.add(tablet);
        
        category.setProducts(prod);
       
        entityManager.persist(category);*/
        
        
        // (class not tablename)
/*String name = "flowers";
   
	TypedQuery<Product>stQuery=entityManager.createQuery("SELECT e FROM Product e WHERE e.name LIKE : name",Product.class);
	stQuery.setParameter("name",name);
	
	List<Product> query = stQuery.getResultList();
	
	stQuery.getResultList();
	for(Product p : query)
	{
		System.out.println("product name:"+ p.getName());
	}
	*/
	Query query1=entityManager.createQuery("SELECT UPPER(e.name) FROM Product e");
	@SuppressWarnings("unchecked")
	List<String>list=query1.getResultList();
	
	for(String e:list) {
		System.out.println(e);
	}
	
	
	
	
	
      
/*if(obj==null){
System.out.println("No Employee found .");
}
else{
for(Product emp1:obj) {
System.out.println("Category name=" +emp1.getId()+emp1.getName());
}

}
        
        
        
                           // (class not tablename)
      /*  List<Category> listEmployee=entityManager.createQuery("SELECT c from Category c ").getResultList();
        if(listEmployee==null){
        	System.out.println("No Employee found .");
        }
        else{
        	for(Category emp1:listEmployee) {
        		System.out.println("Category name=" +emp1.getName());
        	}
        	
        }*/
        
      
      
        
    }
}
