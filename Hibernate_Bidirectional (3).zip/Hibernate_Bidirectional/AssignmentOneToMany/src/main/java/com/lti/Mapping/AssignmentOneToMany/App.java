package com.lti.Mapping.AssignmentOneToMany;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;






public class App 
{
	BankAccount category = new Category("Computer");
    Product pc=new Product("DELL PC","QuadCore", 1200,category);
    
    Product laptop =new Product("MacBook","Apple laptop",2100,category);
    Product phone =new Product("MacBook","Apple laptop",2100,category);
    Product tablet =new Product("MacBook","Apple laptop",2100,category);
    
    Set<Product> prod=new HashSet<Product>();
    prod.add(pc);
    prod.add(laptop);
    prod.add(phone);
    prod.add(tablet);
    
    category.setProducts(prod);
    
    entityManager.getTransaction().commit();
    entityManager.close();
    
       
}
}
