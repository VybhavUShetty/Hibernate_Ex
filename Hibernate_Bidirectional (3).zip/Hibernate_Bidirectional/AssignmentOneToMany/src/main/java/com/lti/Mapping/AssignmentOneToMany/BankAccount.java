package com.lti.Mapping.AssignmentOneToMany;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="BANK_ACCOUNT")
public class BankAccount {
	
	private int accno;
	private String bankname;
	private float balance;
	private Set<Customer> customer;
	
	public BankAccount() {
		
	}

	public int getAccno() {
		return accno;
	}

	public void setAccno(int accno) {
		this.accno = accno;
	}

	public String getBankname() {
		return bankname;
	}

	public void setBankname(String bankname) {
		this.bankname = bankname;
	}

	public float getBalance() {
		return balance;
	}

	public void setBalance(float balance) {
		this.balance = balance;
	}

	public Set<Customer> getCustomer() {
		return customer;
	}

	public void setCustomer(Set<Customer> customer) {
		this.customer = customer;
	}

	@Override
	public String toString() {
		return "BankAccount [accno=" + accno + ", bankname=" + bankname + ", balance=" + balance + ", customer="
				+ customer + "]";
	}

	public BankAccount(int accno, String bankname, float balance, Set<Customer> customer) {
		super();
		this.accno = accno;
		this.bankname = bankname;
		this.balance = balance;
		this.customer = customer;
	}
	
	

	

}
