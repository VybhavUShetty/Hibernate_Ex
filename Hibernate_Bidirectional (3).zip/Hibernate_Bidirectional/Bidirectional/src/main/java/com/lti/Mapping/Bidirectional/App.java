package com.lti.Mapping.Bidirectional;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;


public class App 
{
    public static void main( String[] args )
    {
    
        EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("HEY");
        EntityManager entityManager=entityManagerFactory.createEntityManager();
        
        System.out.println("Starting Transaction");
        entityManager.getTransaction().begin();
        Address address=new Address();
        
   /*  
        Student student=new Student();
        address.setStreet("1st street");
        address.setCity("Mangalore");
        address.setCountry("India");
        address.setStudent(student);
        
        System.out.println("Saving author to database");
        entityManager.persist(address);

        */
        @SuppressWarnings("unchecked")                               // (class not tablename)
        List<Student> listEmployee=entityManager.createQuery("SELECT e FROM Student e").getResultList();
        if(listEmployee==null){
        	System.out.println("No Employee found .");
        }
        else{
        	for(Student emp1:listEmployee) {
        		System.out.println("Employee name=" +emp1.getFirstname()+  ",Student Name ");
        	}
        	
        }
        
  
      
     /*
        student.setFirstname("Vybhav");
        student.setLastname("Shetty");
        student.setSection("Java");
        student.setAddress(address);
        entityManager.persist(student);*/
        entityManager.getTransaction().commit();
        
        entityManager.close();
       entityManagerFactory.close();
}
}
