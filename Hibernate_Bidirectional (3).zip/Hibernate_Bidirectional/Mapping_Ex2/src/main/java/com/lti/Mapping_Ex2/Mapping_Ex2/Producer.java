package com.lti.Mapping_Ex2.Mapping_Ex2;


@Entity
@Table(name="PRODUCER")
public class Producer {
	@Id
	@GeneratedValue(straegy=GenerationType.SEQUENCE,generator="GEN")
	@SequenceGenerator(name=)
	
	

}
