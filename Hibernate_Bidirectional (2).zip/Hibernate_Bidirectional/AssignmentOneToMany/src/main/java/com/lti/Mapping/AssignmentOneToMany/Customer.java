package com.lti.Mapping.AssignmentOneToMany;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="CUSTOMER")
public class Customer {
	private String bankname;
	private int customerid;
	private String customername;
	private String address;
	private int phoneno;
	
	public Customer() {
		
	}

@Column(name="BANK_NAME")

	public String getBankname() {
		return bankname;
	}
	public void setBankname(String bankname) {
		this.bankname = bankname;
	}
	
@Id
@Column(name="CUSTOMER_ID")
@GeneratedValue
	public int getCustomerid() {
		return customerid;
	}
	public void setCustomerid(int customerid) {
		this.customerid = customerid;
	}
@Column(name="CUSTOMER_NAME")
	public String getCustomername() {
		return customername;
	}
	public void setCustomername(String customername) {
		this.customername = customername;
	}

@Column(name="ADDRESS")
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
@Column(name="PHONE_NO")
	public int getPhoneno() {
		return phoneno;
	}
	public void setPhoneno(int phoneno) {
		this.phoneno = phoneno;
	}
	@Override
	public String toString() {
		return "Customer [bankname=" + bankname + ", customerid=" + customerid + ", customername=" + customername
				+ ", address=" + address + ", phoneno=" + phoneno + "]";
	}
	public Customer(String bankname, int customerid, String customername, String address, int phoneno) {
		super();
		this.bankname = bankname;
		this.customerid = customerid;
		this.customername = customername;
		this.address = address;
		this.phoneno = phoneno;
	}
	
	
	
	
	
	
	

}
