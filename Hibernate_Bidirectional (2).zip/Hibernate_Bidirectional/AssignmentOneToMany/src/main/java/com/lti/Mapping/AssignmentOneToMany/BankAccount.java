package com.lti.Mapping.AssignmentOneToMany;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="BANK_ACCOUNT")
public class BankAccount {
	private int accno;
	private float balance;
	private Set<Customer> customer;
	
	public BankAccount() {
		
	}
@Id
@Column(name="ACCOUNT_NO")
@GeneratedValue
	public int getAccno() {
		return accno;
	}

	public void setAccno(int accno) {
		this.accno = accno;
	}
@Column(name="BALANCE")
	public float getBalance() {
		return balance;
	}

	public void setBalance(float balance) {
		this.balance = balance;
	}
	@OneToMany(mappedBy="customer",cascade=CascadeType.ALL)
	public Set<Customer> getCustomer() {
		return customer;
	}

	public void setCustomer(Set<Customer> customer) {
		this.customer = customer;
	}

	@Override
	public String toString() {
		return "BankAccount [accno=" + accno + ", balance=" + balance + ", customer=" + customer + "]";
	}

	public BankAccount(int accno, float balance, Set<Customer> customer) {
		super();
		this.accno = accno;
		this.balance = balance;
		this.customer = customer;
	}
	
	

}
